<?php

namespace Drupal\module_import\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;

/**
 * Class MyImportQueueWorker
 *
 * @package Drupal\module_import\Plugin\QueueWorker
 *
 * @QueueWorker(
 *   id = "module_import_queue_worker",
 *   title = @Translation("Import à moi")
 * )
 */
class MyImportQueueWorker extends QueueWorkerBase {

    /**
     * @param mixed $item
     */
    public function processItem($item) {
        [$function, $operation] = $item;
        [$data] = $operation;

        $function($data);
    }
}
